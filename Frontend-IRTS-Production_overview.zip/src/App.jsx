import { useState } from 'react'
import './App.css'
import AppRouting from './routes/AppRouting'

function App() {


  return (
    <>
    <AppRouting/>
    </>
  )
}

export default App
