import React from 'react'
import { Outlet } from 'react-router-dom'
const ProductionMain = () => {
  return (
    <div>
        <Outlet/>
    </div>
  )
}
export default ProductionMain